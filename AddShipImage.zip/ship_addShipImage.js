//ver1.5.2
//Author: Nishisonic

load("script/utils.js");

function header() {
	return ["画像"];
}

function begin(specdiff) {}

function body(ship) {
	return toComparable([null]);
}

function end() {}
